# Antigravity Master Prompt

Act as lead TypeScript computational-geometry engineer. Read the entire package before coding.

Hard requirements:
1. strict TypeScript, zero `any` in core;
2. immutable CanonicalPolygon;
3. solver must never import Martinez;
4. TopologyValidator is the Judge; TopologyNormalizer is the Canonicalizer;
5. implement true residual/Jacobian evaluation and damped nonlinear least squares;
6. DoF = 2N - numerical rank(J), not equation count;
7. use a stable rank-revealing decomposition; do not call JᵀJ eigen-analysis SVD;
8. fixed points are hard constraints;
9. implement explicit EDGE_LENGTH, PARALLEL, PERPENDICULAR, HORIZONTAL, VERTICAL and RECTANGLE semantics;
10. distinguish under-constrained, solved and conflicting hard constraints;
11. add certification tests before UI;
12. isolate Martinez behind a Boolean adapter;
13. route all mutations through CommandDispatcher with undo/redo;
14. do not begin Phase 13 Flying Stars until Phase 12 certification passes.

Run npm install, npm run typecheck and npm test before UI work.
