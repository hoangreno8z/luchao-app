# Phase 12 Audit

## Required corrections
- DoF must use numerical rank of the Jacobian, not equation count.
- Eigen-analysis of JᵀJ is not SVD; production rank detection needs a stable rank-revealing method.
- Sequential projection can move fixed vertices; hard constraints need explicit treatment.
- RECTANGLE semantics must be explicit.
- Distinguish under-constrained, solved and conflicting systems.
- Validate duplicate non-adjacent vertices, self intersections, zero area and invalid holes.
- Martinez remains behind a foreign-data adapter and is invisible to the solver.
- Solver output is a candidate until TopologyValidator accepts it; only then does TopologyNormalizer create CanonicalPolygon.
