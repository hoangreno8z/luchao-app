# Architecture

UI → CommandDispatcher → ConstraintGraph → Numerical Solver → Candidate
→ TopologyValidator (Judge) → TopologyNormalizer (Canonicalizer) → CanonicalPolygon.

CanonicalPolygon is deeply immutable. Martinez is an external Boolean adapter.
Phase 13 must not consume mutable draft geometry.
