# Boolean Adapter Boundary

Martinez belongs only in this adapter layer. Convert CanonicalPolygon to foreign data, run boolean, then validate and normalize all returned rings. Constraint solver must never import Martinez.
