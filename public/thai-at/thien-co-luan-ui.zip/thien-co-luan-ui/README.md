# Thiên Cơ Luân UI
Đặt 4 artwork vào `public/images/`: `kinh-dich.webp`, `tu-vi.webp`, `bat-tu.webp`, `thai-at.webp`.
Sau đó copy `components/CelestialHome.tsx`, `app/globals.css`, `app/page.tsx`, `app/layout.tsx` vào dự án Next.js hiện tại.
