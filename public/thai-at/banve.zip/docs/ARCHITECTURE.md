# CAD + FENG SHUI ARCHITECTURE

UI -> CommandDispatcher -> Domain Commands -> Geometry/Constraint/FengShui Core

## Boundary

React/SVG/Canvas
        |
        v
CommandDispatcher
        |
        +--> FootprintModel
        +--> ConstraintGraph
        +--> CompassOverlay
        +--> RoomGraph
        |
        v
Geometry Kernel
        |
        +--> Candidate
        +--> TopologyValidator
        +--> TopologyNormalizer
        |
        v
Canonical Geometry

Martinez chỉ tồn tại trong `core/engine` adapter.

## Golden rule

CanonicalPolygon là immutable domain object.
Không module ngoài geometry kernel được tạo `_brand` giả.
Không expose MartinezPolygon ra UI.
