# UI ACCEPTANCE CHECKLIST

## Canvas
[ ] pan / zoom
[ ] fit
[ ] grid
[ ] snap
[ ] coordinate readout
[ ] scale/unit

## Architectural plan
[ ] real walls with thickness
[ ] room polygons
[ ] L shape
[ ] U shape
[ ] stepped footprint
[ ] arbitrary concave polygon
[ ] door swing
[ ] window opening
[ ] stairs
[ ] furniture symbols
[ ] dimensions
[ ] area labels
[ ] north arrow

## La Kinh
[ ] overlay on plan
[ ] draggable center
[ ] rotate by bearing
[ ] 360 degree ring
[ ] 24 Sơn
[ ] 72 Long / 5 degree sectors
[ ] degree readout
[ ] 8 directions
[ ] 4 cardinal directions
[ ] 24 mountain labels
[ ] toggle north-up / house-direction-up
[ ] footprint clipping / transparent overlay

## Feng Shui
[ ] 9-palace grid derives from actual footprint bounds or selected reference frame
[ ] compass and footprint share one coordinate transform
[ ] no hard-coded screen coordinates
[ ] room-to-palace intersection is geometric
[ ] room area percentage per palace
[ ] direction is computed from geometry

## QA
[ ] 0/360 continuity
[ ] 5/10/15 degree boundaries
[ ] L/U/stepped topology
[ ] holes
[ ] MultiPolygon
[ ] self-intersection
[ ] zero area
[ ] overconstraint
[ ] underconstraint
[ ] conflicting constraints
