Bạn đang tiếp quản một web app Phong Thủy & Kiến Trúc đã triển khai.

URL tham chiếu:
https://lapque.vercel.app/phong-thuy/

NHIỆM VỤ:
Không được chỉ thêm tính năng. Hãy tái cấu trúc phần CAD để bản vẽ có chất lượng architectural floor-plan.

BẮT BUỘC:
1. Audit code hiện tại trước.
2. Không phá logic Kinh Dịch/Lục Hào/Thái Ất đang đúng.
3. Tách geometry core khỏi UI.
4. Dùng CanonicalPolygon làm domain boundary.
5. Martinez chỉ nằm trong adapter.
6. Boolean phải xử lý Polygon + MultiPolygon + holes.
7. Constraint solver dùng residual/Jacobian toàn cục.
8. DoF dùng numerical rank, không chỉ equation count.
9. topology phải là Judge độc lập.
10. normalizer là canonicalizer cuối.

CAD EDITOR:
- SVG hoặc Canvas đều được nhưng geometry phải model-driven.
- footprint là polygon thật.
- hỗ trợ rectangle/L/U/stepped/arbitrary concave.
- wall thickness bằng offset.
- rooms là polygons.
- doors/windows/stairs là geometry objects.
- dimensions bám vào geometry.
- snapping endpoint/midpoint/intersection/perpendicular/parallel.
- zoom/pan/fit.
- units m/mm.
- không dùng div để giả lập bản vẽ.

LA KINH:
- Overlay trực tiếp lên bản vẽ.
- 360°.
- 24 Sơn, 15°/Sơn.
- mỗi Sơn chia 3 phân khu 5° => 72 Long.
- Không ghi "72 Sơn".
- Có tâm đo.
- Có bearing.
- Có North-up và House-direction-up.
- La Kinh phải transform cùng coordinate system với footprint.
- kéo tâm/đổi hướng phải cập nhật overlay theo geometry, không repaint thủ công.
- hỗ trợ 0°/360° wrap.

PHONG THỦY:
- tính hướng từ vector cạnh/mặt tiền được chọn.
- 9 cung phải nằm trong reference frame rõ ràng.
- phòng được phân loại theo giao cắt hình học với cung.
- không hard-code vị trí phòng trên canvas.

UI:
Bản vẽ chính phải chiếm diện tích lớn.
Panel điều khiển không được che canvas.
Có toolbar CAD.
Có layer visibility.
Có status bar tọa độ/bearing/scale.
Có dimension labels.
Có legend La Kinh.

TEST:
- rectangle 12x8 => area 96.
- L shape.
- U shape.
- self-intersection rejected.
- zero area rejected.
- fixed point + conflicting edge length => conflict.
- underconstrained => report DoF > 0, không giả vờ unique.
- 24 Sơn đúng.
- 72 Long đúng.
- 179.999° và 180° đúng.
- MultiPolygon Martinez đúng.

TRƯỚC KHI BÁO DONE:
npm test
npm run typecheck
npm run build

Sau đó chụp/kiểm tra trực quan 5 mẫu:
1 rectangle
2 L
3 U
4 stepped
5 skewed polygon

Nếu UI vẫn trông như sơ đồ trẻ em, coi như FAIL và tiếp tục sửa.
