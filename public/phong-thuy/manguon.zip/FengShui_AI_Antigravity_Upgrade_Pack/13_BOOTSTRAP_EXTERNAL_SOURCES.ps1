$ErrorActionPreference = "Stop"

New-Item -ItemType Directory -Force vendor | Out-Null

$repos = @(
  "https://github.com/JackieL233/fengshui-master.git",
  "https://github.com/Sudo-Biao/suangua.git",
  "https://github.com/huy555huy/suan.git",
  "https://github.com/ShousenZHANG/chinese-fortune.git"
)

foreach ($url in $repos) {
    $name = [System.IO.Path]::GetFileNameWithoutExtension($url)
    if (!(Test-Path "vendor/$name")) {
        git clone --depth 1 $url "vendor/$name"
    }
}

Write-Host "External references downloaded. Read LICENSE files before importing code."
