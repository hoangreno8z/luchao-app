# AI TOOL CONTRACTS

LLM tools must be schema-bound.

## `calculate_luopan`

Input:
```json
{
  "bearingDeg": 0,
  "northBasis": "true"
}
```

Output:
```json
{
  "bearingDeg": 0,
  "mountain": "...",
  "confidence": 1,
  "warnings": []
}
```

## `analyze_floorplan`

Input:
```json
{
  "planId": "...",
  "mode": "assist"
}
```

Output:
- candidates
- confidence
- evidence
- no silent mutations.

## `calculate_xuan_kong`

Never accept free-form instructions as algorithm parameters.

Input must be typed:
```json
{
  "schoolProfile": "..."
}
```

## `interpret_fengshui`

LLM receives:
- chart
- evidence
- source refs
- user-selected school
- warnings.

It cannot alter chart.
