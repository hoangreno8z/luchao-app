# SECURITY BLUEPRINT

## 1. Secrets

KHÔNG BAO GIỜ:
- đặt Gemini/OpenAI/Supabase service key trong JS client;
- commit `.env`;
- đưa secret vào HTML;
- log secret.

Chỉ dùng:
- Vercel Environment Variables
- server-side functions
- secret rotation.

Client chỉ nhận public configuration cần thiết.

## 2. API

Mọi endpoint phải:
1. validate method
2. validate content type
3. validate schema
4. authenticate nếu cần
5. authorize resource
6. rate limit
7. size limit
8. perform action
9. sanitize output
10. audit event nếu cần.

## 3. Upload

Cho phép whitelist:
- image/jpeg
- image/png
- image/webp
- application/pdf

Giới hạn:
- file size
- pixel count
- PDF page count
- decompression ratio.

Không tin extension.
Không tin Content-Type từ client.
Kiểm tra magic bytes ở server.

Không tự động fetch URL do người dùng nhập.

## 4. SSRF

Nếu tương lai hỗ trợ import từ URL:
- allowlist domain
- resolve DNS
- block private IP ranges
- block localhost
- block metadata endpoints
- limit redirects
- timeout
- response size limit.

## 5. Authorization

Không chỉ kiểm tra:
`userId === request.userId`.

Mỗi object phải kiểm tra quyền sở hữu ở server.

## 6. Rate limit

Tách:
- public calculations
- authenticated calculations
- AI interpretation
- vision processing
- upload.

AI và vision phải có quota.

## 7. Prompt injection

File bản vẽ/OCR text/knowledge:
- coi là untrusted input.
- không được phép ghi đè system instructions.
- không cho retrieved text thực thi code.
- tool arguments phải schema validate.

## 8. CSP

Dùng Content-Security-Policy phù hợp với deployment.
Không bật `unsafe-eval` nếu không cần.
Giảm `unsafe-inline`.

## 9. Headers

Thiết lập:
- Strict-Transport-Security
- X-Content-Type-Options
- Referrer-Policy
- Permissions-Policy
- CSP
- frame-ancestors.

## 10. Logging

Không log:
- API keys
- tokens
- private user documents
- full uploaded drawings
- unnecessary personal data.

## 11. Dependencies

Mỗi phase:
- npm audit / equivalent
- dependency review
- lockfile required.

## 12. OWASP

Thiết kế theo OWASP API Security Top 10 2023:
BOLA, broken auth, property-level auth, resource consumption, function-level auth, sensitive business flow, SSRF, misconfiguration, inventory, unsafe API consumption.

## 13. Threat model

Các threat chính:
- XSS
- CSRF
- SSRF
- upload bombs
- oversized image
- malicious PDF
- API abuse
- token theft
- prompt injection
- data leakage
- unauthorized chart access
- excessive AI spending
- dependency compromise.
