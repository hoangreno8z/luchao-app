# UI SYSTEM

## Mục tiêu

Không dùng emoji.
Không dùng template SaaS.
Không dùng giao diện game.
Không dùng icon lòe loẹt.

Tất cả visual đặc thù Phong Thủy được vẽ bằng code.

## Layout

Desktop:
```text
┌───────────────────────────────────────────┐
│ Header                                    │
├───────────────┬───────────────────────────┤
│ Tools         │                           │
│               │       Drawing Canvas      │
│ Layers        │                           │
│               │                           │
├───────────────┴───────────────────────────┤
│ Status / Analysis                          │
└───────────────────────────────────────────┘
```

Mobile:
```text
┌─────────────────┐
│ Header          │
├─────────────────┤
│                 │
│ Canvas          │
│                 │
├─────────────────┤
│ Compact toolbar │
└─────────────────┘
```

## Buttons

Tên ngắn:
- Chọn
- Vẽ
- Tường
- Phòng
- Cửa
- Cửa sổ
- Thang
- Tâm
- Hướng
- La Kinh
- Cửu Cung
- Phi Tinh
- Lớp
- So sánh
- Phân tích

Không dùng:
- "AI Magic Smart Ultimate Analysis"
- tên marketing dài.

## Group controls

Các chức năng đồng bộ:
- Hình học
- Kiến trúc
- La Kinh
- Phân tích

mỗi nhóm có collapse.

## Layer opacity

Source image:
0–100%.

La Kinh:
mặc định 20–35%.

Cửu Cung:
mặc định 15–25%.

Guides:
mặc định 30–50%.

## Drawing

- hairline strokes
- anti-aliased
- no filled opaque overlay unless explicitly selected.
- selected object may use translucent fill.
- text follows viewport scale.

## Typography

Mọi label phải:
- `white-space: nowrap` khi phù hợp
- `overflow: hidden`
- `text-overflow: ellipsis`
- không vượt panel.
- không để text đè lên canvas.

## Accessibility

- keyboard navigation
- focus ring
- aria-label
- tooltip chỉ khi cần
- contrast đủ.
