#!/usr/bin/env bash
set -euo pipefail

mkdir -p vendor

repos=(
  "https://github.com/JackieL233/fengshui-master.git"
  "https://github.com/Sudo-Biao/suangua.git"
  "https://github.com/huy555huy/suan.git"
  "https://github.com/ShousenZHANG/chinese-fortune.git"
)

for url in "${repos[@]}"; do
  name="$(basename "$url" .git)"
  if [ ! -d "vendor/$name" ]; then
    git clone --depth 1 "$url" "vendor/$name"
  fi
done

echo "External references downloaded. Read LICENSE files before importing code."
