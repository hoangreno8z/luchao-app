# VIỆT HÓA

Production UI phải tiếng Việt.

Không dùng chữ Trung trong UI trừ khi người dùng bật chế độ học thuật/đối chiếu.

Tên hiển thị:
- La Kinh
- Cửu Cung
- Bát Quái
- 24 Sơn
- Huyền Không Phi Tinh
- Bát Trạch
- Hình Pháp
- Bản vẽ
- Lớp
- Tâm nhà
- Hướng
- Bắc thật
- Bắc từ
- So sánh
- Phân tích.

Code identifiers vẫn dùng English để dễ bảo trì.

Thông báo lỗi:
- ngắn
- rõ
- có hướng xử lý.

Ví dụ:
"Không xác định được tâm nhà. Hãy kiểm tra đường bao công trình."

Không:
"AI đang gặp sự cố kỳ bí."
