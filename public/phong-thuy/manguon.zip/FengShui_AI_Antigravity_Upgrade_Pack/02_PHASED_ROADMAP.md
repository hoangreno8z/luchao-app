# ROADMAP NÂNG CẤP AN TOÀN

## Phase 0 — Baseline
Không sửa code.

- clone repo
- build
- chạy production-like
- chụp màn hình tab Phong Thủy
- đo load
- xác định current DOM
- xác định current API
- tạo `BASELINE.md`.

PASS → Phase 1.

## Phase 1 — Refactor nhẹ và chuẩn hóa
Mục tiêu: không thay đổi hành vi.

- gom constants
- thêm TypeScript types nếu tương thích
- tách pure functions
- chuẩn hóa naming
- không đổi UI.

Gate:
build + regression.

## Phase 2 — UI shell
Chỉ chuẩn hóa layout.

- canvas
- toolbar
- collapsible panels
- layer panel
- property panel.

Không có algorithm mới.

Gate:
desktop + mobile + screenshot.

## Phase 3 — Drawing Engine
Thêm:
- pan
- zoom
- selection
- snapping
- layers
- vector objects.

Gate:
100% drawing tests cơ bản.

## Phase 4 — Source Image Layer
- upload
- validate
- opacity
- lock
- compare.

Không AI.

## Phase 5 — Geometry Engine
- polygon
- wall
- room
- centroid
- interior point
- coordinate transform.

Gate:
golden geometry fixtures.

## Phase 6 — Manual Architecture Library
Trước AI.

- wall
- room
- door
- window
- stair
- toilet
- kitchen
- bedroom
- living room
- worship room
- office
- balcony
- corridor
- shaft
- column
- furniture.

Người dùng có thể vẽ/sửa thủ công.

## Phase 7 — Vision Assist
AI chỉ đề xuất.

- line detection
- OCR
- symbol detection
- room classification
- confidence.

Không auto-lock.

## Phase 8 — Luopan
- bearing
- north basis
- 24 mountains
- rings
- SVG renderer.

Golden tests bắt buộc.

## Phase 9 — Bagua/Cửu Cung
- coordinate transform
- 8 trigrams
- 9 palaces
- overlays.

Không làm interpretation.

## Phase 10 — Xuan Kong Engine
Chỉ triển khai các thuật toán đã có nguồn + test.

Mỗi trường phái/profile phải có version.

## Phase 11 — Form School
- road
- water
- entrance
- sha
- mountain
- shape.

## Phase 12 — Ba Zhai
Tách khỏi Xuan Kong.

## Phase 13 — Evidence Graph
Mỗi kết luận truy ngược được về:
input → calculation → rule → source.

## Phase 14 — RAG
Chỉ retrieve tài liệu liên quan.
Không cho model đọc toàn bộ knowledge dump.

## Phase 15 — AI Interpretation
AI giải thích chart/evidence.
Không tính lại.

## Phase 16 — What-if Simulator
Clone state → thay đổi → recompute → diff.

## Phase 17 — Security hardening
- auth
- authorization
- rate limits
- upload limits
- CSP
- CORS
- SSRF
- audit
- dependency audit.

## Phase 18 — Performance
- mobile
- low-end
- worker
- code split
- bundle analysis.

## Phase 19 — Release Candidate
Chạy toàn bộ suite.

## Phase 20 — Production
Chỉ deploy khi mọi gate PASS.
