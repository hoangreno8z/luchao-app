# SOURCE / LICENSE POLICY

Mục tiêu không phải gom code càng nhiều càng tốt.

Mục tiêu là:
- học được thuật toán
- chọn được implementation tốt
- giữ attribution
- tránh license conflict
- tránh kéo dependency không cần thiết.

Khi import:
1. giữ LICENSE.
2. ghi source URL.
3. ghi source commit.
4. ghi file đã import.
5. ghi modifications.
6. chạy license audit.

Không chép nguyên một repository vào production chỉ vì nó "open source".

Nếu license không rõ:
- không import code.
- chỉ dùng ý tưởng/kiến trúc ở mức phù hợp.
