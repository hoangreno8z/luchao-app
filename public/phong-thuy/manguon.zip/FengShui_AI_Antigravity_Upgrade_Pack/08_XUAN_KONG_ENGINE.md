# XUAN KONG ENGINE

## Critical rule

Không triển khai công thức nào nếu chưa:
- xác định school/profile
- xác định source
- viết rule spec
- viết deterministic function
- có golden test.

## Data model

```ts
type XuanKongInput = {
  period: number;
  facingDeg: number;
  sittingDeg: number;
  mountainId: string;
  schoolProfile: string;
};

type StarPlacement = {
  palace: number;
  star: number;
  role: "base" | "mountain" | "water";
};
```

## Profile isolation

```text
schools/
  xuan-kong-fei-xing/
  ba-zhai/
  form-school/
```

Không import rule của school A vào school B.

## Output

Mọi chart phải trả:
- input
- assumptions
- chart
- rule version
- source refs
- test refs
- warnings.

## No silent corrections

Nếu input thiếu:
- period
- facing
- reliable bearing

trả `incomplete`.

Không tự đoán.
