# OPEN SOURCE REFERENCE MANIFEST

## 1. FengShui Master

Repository:
https://github.com/JackieL233/fengshui-master

Use for:
- skill architecture
- floorplan schema
- Luopan helper concepts
- 24 mountains
- school mapping
- RAG/reference organization
- tests/evaluation
- deterministic helpers.

License shown by repository: MIT.

## 2. Suangua

Repository:
https://github.com/Sudo-Biao/suangua

Use for:
- pure calculation engine separation
- Pydantic/data validation patterns
- Feng Shui module organization
- RAG/BM25 architecture
- API separation
- test patterns.

License shown by repository: MIT.

## 3. Suan

Repository:
https://github.com/huy555huy/suan

Use for:
- Agent/tool architecture
- skill routing
- deterministic computation separated from LLM
- knowledge/rules organization
- evidence-oriented agent workflow.

License must be checked at integration time.

## 4. Chinese Fortune

Repository:
https://github.com/ShousenZHANG/chinese-fortune

Use for:
- deterministic engines
- method routing
- test/evaluation gates
- school references
- Feng Shui skill organization.

License shown by repository: MIT.

## 5. Current application

Repository:
https://github.com/hoangreno8z/luchao-app

This is the primary project.
Do not replace it.

## Important

Do not copy external code blindly.
For each imported file:
- preserve LICENSE/NOTICE
- record source repository
- record commit/tag
- record local modifications
- run dependency/license checks.

If network is available, run:

```bash
git clone --depth 1 https://github.com/JackieL233/fengshui-master.git vendor/fengshui-master
git clone --depth 1 https://github.com/Sudo-Biao/suangua.git vendor/suangua
git clone --depth 1 https://github.com/huy555huy/suan.git vendor/suan
git clone --depth 1 https://github.com/ShousenZHANG/chinese-fortune.git vendor/chinese-fortune
```

Do NOT vendor giant unrelated modules. Extract only the relevant patterns/modules after review.
