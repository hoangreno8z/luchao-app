# KIẾN TRÚC KỸ THUẬT

## Nguyên tắc

Pure calculation trước, UI sau, LLM cuối.

```text
UI
 |
 | user intent
 v
Application Layer
 |
 +--> Drawing Engine
 |
 +--> Geometry Engine
 |
 +--> Luopan Engine
 |
 +--> Xuan Kong Engine
 |
 +--> Ba Zhai Engine
 |
 +--> Form Engine
 |
 +--> Evidence Engine
 |
 +--> Knowledge/RAG
 |
 +--> AI Interpretation
```

## Cấu trúc đề xuất

Không ép repo phải đổi ngay. Chỉ tạo từng thư mục khi phase tương ứng PASS.

```text
phong-thuy/
  index.html
  style.css
  js/
    app/
      state.js
      commands.js
      selectors.js

    ui/
      toolbar/
      panels/
      dialogs/
      responsive/

    canvas/
      renderer.js
      viewport.js
      hitTest.js
      layers.js
      selection.js

    geometry/
      polygon.js
      centroid.js
      pointInPolygon.js
      topology.js
      transforms.js

    architecture/
      objects.js
      roomClassifier.js
      wallGraph.js
      doorGraph.js

    vision/
      preprocess.js
      lineDetection.js
      ocrAdapter.js
      roomAdapter.js
      confidence.js

    luopan/
      bearing.js
      mountains24.js
      rings.js
      renderer.js
      north.js

    xuan-kong/
      periods.js
      luo-shu.js
      flying.js
      chart.js
      rules.js

    ba-zhai/
      ming-gua.js
      directions.js
      rules.js

    form-school/
      entrance.js
      road.js
      water.js
      shape.js

    knowledge/
      registry.js
      schoolProfiles.js
      evidence.js

    interpretation/
      report.js
      scoring.js

    security/
      sanitize.js
      upload-policy.js

  data/
    luopan/
    schools/
    rules/
    room-library/

  tests/
    geometry/
    luopan/
    xuan-kong/
    vision/
    ui/
    security/
```

## Domain model

```ts
type Point = { x: number; y: number };

type Polygon = {
  points: Point[];
  closed: boolean;
};

type PlanObject = {
  id: string;
  type:
    | "wall"
    | "room"
    | "door"
    | "window"
    | "stair"
    | "toilet"
    | "kitchen"
    | "bedroom"
    | "living"
    | "worship"
    | "office"
    | "balcony"
    | "column"
    | "furniture";
  geometry: Polygon | Point[];
  confidence: number;
  status: "detected" | "confirmed" | "rejected" | "manual";
  source: "user" | "vision" | "import";
};
```

## State machine

Không mutate state tùy tiện.

```text
EMPTY
 -> SOURCE_LOADED
 -> DETECTING
 -> DETECTED
 -> REVIEW
 -> CONFIRMED
 -> ORIENTED
 -> LUOPAN_READY
 -> ANALYSIS_READY
```

Không được chạy Xuan Kong nếu orientation chưa valid.
Không được chạy room analysis nếu geometry chưa valid.
