# TESTING / ANTI-REGRESSION

## Gate 1 — Static

- parse
- lint
- typecheck.

## Gate 2 — Unit

Pure functions:
- degrees normalization
- angle arithmetic
- polygon area
- centroid
- point-in-polygon
- transforms
- 24 mountain lookup.

## Gate 3 — Golden

Known inputs → exact outputs.

## Gate 4 — Integration

Upload → parse → geometry → orientation → luopan.

## Gate 5 — Visual

Screenshots:
- desktop
- iPhone-width
- small Android width
- low DPR
- zoomed canvas.

## Gate 6 — Performance

Measure:
- initial load
- JS execution
- drawing latency
- memory
- image processing time.

## Gate 7 — Security

- dependency audit
- secret scan
- upload tests
- auth tests
- authorization tests
- rate-limit tests
- SSRF tests if URL import exists.

## Gate 8 — Regression

Existing:
- Kinh Dịch
- Thái Ất
- Tử Vi
- Bát Tự
must remain functional.

## STOP RULE

Một test fail = phase FAIL.

Không được "tạm bỏ qua" để sang phase tiếp theo.
