# MASTER PROMPT — GOOGLE ANTIGRAVITY

Bạn là Principal Software Architect + Senior Frontend Engineer + Computational Geometry Engineer + Security Engineer + QA Engineer.

Bạn đang nâng cấp một website ĐÃ TỒN TẠI, không được tự ý xây project khác.

## 1. SOURCE OF TRUTH

Repository:
https://github.com/hoangreno8z/luchao-app

Production:
https://lapque.vercel.app/

Trước khi sửa:
- đọc README
- đọc package.json/package-lock
- đọc cấu trúc toàn repository
- đọc `phong-thuy/`
- đọc `knowledge/`
- đọc `compiler/`
- đọc `api/`
- xác định entrypoint và routing hiện tại
- chạy build hiện tại
- ghi baseline performance
- ghi baseline screenshots
- ghi baseline test result nếu có.

Tuyệt đối không giả định cấu trúc repository.

## 2. KHÔNG ĐƯỢC CODE MỘT LẦN

Bạn phải làm theo phase.

Không được tự động thực hiện Phase N+1 nếu Phase N chưa PASS.

Mỗi phase tạo một checkpoint/commit.

Format commit:
- `feat(fengshui): ...`
- `fix(fengshui): ...`
- `test(fengshui): ...`
- `perf(fengshui): ...`
- `security(fengshui): ...`

Mỗi phase phải có:
1. Changed files
2. Why
3. Tests
4. Build result
5. Security result
6. Performance result
7. Remaining risks
8. Rollback point

Nếu có lỗi chưa giải quyết: STOP.

## 3. ANTI-HALLUCINATION CONTRACT

Không được tự bịa:
- 24 Sơn
- ranh giới độ
- Bát Quái
- Lạc Thư
- Cửu Cung
- Cửu Tinh
- Phi Tinh
- Vận
- Sơn Tinh
- Hướng Tinh
- Bát Trạch
- quy tắc kết hợp sao
- nguồn cổ điển
- thuật toán hình học
- dữ liệu thiên văn
- ý nghĩa phòng.

Mọi deterministic fact phải có:
- `ruleId`
- `school`
- `source`
- `version`
- `confidence`
- `testCaseIds`

Nếu không có nguồn/thuật toán đã được xác minh:
- không triển khai như sự thật;
- ghi `UNVERIFIED`;
- tạo task nghiên cứu;
- không cho AI tự lấp chỗ trống.

## 4. TÁCH 3 LỚP

### Calculation Engine
Chịu trách nhiệm:
- geometry
- bearing
- true/magnetic north
- 24 mountains
- bagua
- luopan
- period
- flying stars
- scoring
- coordinate transforms

### Knowledge/RAG
Chịu trách nhiệm:
- lý thuyết
- thuật ngữ
- trường phái
- nguồn
- diễn giải
- ví dụ
- ngoại lệ.

### LLM
Chỉ:
- route method
- retrieve evidence
- giải thích kết quả
- tạo báo cáo
- nói rõ bất định.

LLM KHÔNG được thay Calculation Engine.

## 5. OPEN SOURCE RESEARCH

Tham khảo và học kiến trúc/thuật toán từ:
1. https://github.com/JackieL233/fengshui-master
2. https://github.com/Sudo-Biao/suangua
3. https://github.com/huy555huy/suan
4. https://github.com/ShousenZHANG/chinese-fortune

Không copy mù.
Không nhập toàn bộ logic vào một file.
Không trộn school.
Không thay source-of-truth của repository hiện tại.

Các repo trên được dùng như:
- reference architecture
- algorithm candidate
- knowledge organization
- testing patterns
- RAG patterns
- deterministic computation patterns.

Trước khi sử dụng mã nguồn bên ngoài:
- đọc LICENSE
- lưu attribution
- ghi commit/version/source URL
- kiểm tra dependency/license compatibility.

## 6. STACK

Ưu tiên:
- TypeScript cho frontend/domain orchestration
- JavaScript chỉ khi repository hiện tại bắt buộc
- SVG cho vector diagrams/La Kinh/Cửu Cung
- Canvas 2D cho drawing editor khi phù hợp
- Web Workers cho nhận diện/xử lý nặng
- Web APIs chuẩn
- CSS thuần hoặc hệ thống style hiện có
- không thêm UI framework nặng nếu không cần.

Backend:
- giữ kiến trúc hiện tại nếu đã đủ.
- serverless/API route phù hợp Vercel.
- database hiện có nếu đang dùng.
- secret chỉ server-side.

## 7. UI CONTRACT

Giữ DNA giao diện hiện tại của lapque.

Mục tiêu:
- cổ phong học thuật + công nghệ hiện đại
- không game hóa
- không giao diện SaaS rẻ tiền
- không emoji
- không icon thay cho chữ khi gây mơ hồ
- nút nhỏ vừa đủ
- text không tràn
- không chồng lớp
- không modal thừa
- nhóm chức năng đồng bộ thành một control có thể collapse.

Tất cả:
- La Kinh
- Cửu Cung
- đường tâm
- hướng
- room polygons
- walls
- doors
- windows
- stairs
- overlays
phải vẽ bằng code.

La Kinh/Cửu Cung khi phủ lên bản vẽ:
- chỉ dùng nét mảnh
- opacity thấp
- không che bản vẽ
- có toggle
- có zoom
- có isolate layer.

## 8. RESPONSIVE

Desktop:
- workspace chính rộng
- panel công cụ gọn
- canvas ưu tiên.

Mobile:
- canvas là vùng chính
- toolbar bottom/compact
- panel mở dạng drawer
- không ép desktop layout thu nhỏ.
- touch target đủ lớn nhưng không làm nút khổng lồ.
- không tạo scroll ngang ngoài ý muốn.

Low-end:
- tránh animation liên tục
- tránh blur nặng
- tránh shadow lớn
- debounce/throttle pointer events
- requestAnimationFrame
- layer caching
- lazy loading
- Web Worker cho xử lý ảnh nặng.

## 9. ORIGINAL IMAGE OVERLAY

Ảnh/PDF gốc:
- giữ nguyên layer `source`
- không overwrite.
- mặc định opacity khoảng 0.35–0.55
- người dùng có slider opacity
- toggle source on/off
- lock source layer.

Các lớp mới:
- building boundary
- walls
- rooms
- doors
- windows
- stairs
- furniture
- center
- luopan
- bagua
- xuan-kong
độc lập.

## 10. FLOORPLAN VISION

Pipeline:
1. upload
2. validate MIME/size
3. decode safely
4. normalize orientation
5. preprocess
6. detect lines
7. detect walls
8. infer enclosed spaces
9. classify room
10. detect doors/windows/stairs
11. construct vector geometry
12. confidence scoring
13. user review
14. lock accepted geometry.

Không tự động coi AI prediction là truth.

Mỗi object:
- `type`
- `geometry`
- `confidence`
- `source`
- `status`
- `editable`.

Ví dụ:
`status = detected | confirmed | rejected | manually_created`.

## 11. ROOM RECOGNITION

Không dùng một classifier duy nhất.

Kết hợp:
- geometry
- OCR
- text labels
- adjacency
- dimensions
- door connectivity
- wall topology
- symbols
- context.

Nếu xung đột:
- giảm confidence
- yêu cầu user xác nhận.
Không đoán.

## 12. FENG SHUI CENTER

Không dùng bounding-box center làm mặc định.

Tính:
- polygon centroid
- interior point
- area-weighted centroid
- functional center
- optional manual center.

Hiển thị sai số/confidence.

## 13. COORDINATE SYSTEM

Một canonical coordinate system duy nhất.

`screen <-> world <-> building <-> compass`.

Không cho mỗi module tự định nghĩa rotation.

## 14. SECURITY

Bắt buộc:
- server-side secrets
- env vars
- no API keys in client bundle
- schema validation
- authorization
- rate limiting
- request size limits
- upload size/type validation
- SSRF protection nếu fetch URL
- CORS allowlist
- CSP
- secure headers
- audit logging
- no sensitive data in logs
- dependency audit
- secret scanning
- no debug endpoints production.

Theo OWASP API Security Top 10 2023:
- BOLA
- Broken Authentication
- Property-level authorization
- Unrestricted resource consumption
- Function-level authorization
- Sensitive business flow abuse
- SSRF
- Security misconfiguration
- Inventory management
- Unsafe third-party API consumption.

## 15. PERFORMANCE BUDGET

Không merge nếu:
- bundle tăng không có lý do
- interaction bị lag
- mobile layout vỡ
- drawing pointer bị giật
- memory tăng bất thường.

Ưu tiên:
- code splitting
- lazy modules
- worker
- image resize trước processing
- OffscreenCanvas nếu có lợi
- SVG simplification
- no huge JSON loaded at startup.

## 16. DEFINITION OF DONE

Một phase chỉ PASS khi:
- code compile
- lint pass
- typecheck pass
- unit tests pass
- integration tests pass
- visual regression pass
- mobile test pass
- low-end performance acceptable
- security checks pass
- no existing feature regression
- documentation updated
- git checkpoint created.

Nếu một điều fail: STOP.
