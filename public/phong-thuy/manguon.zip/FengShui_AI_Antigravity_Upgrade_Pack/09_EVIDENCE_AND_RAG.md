# EVIDENCE + RAG

## Evidence-first

Mọi kết luận:
```text
Conclusion
 ↓
Rule
 ↓
Calculated Fact
 ↓
Input
```

Ví dụ:

```json
{
  "claimId": "CLAIM-001",
  "text": "...",
  "calculation": {
    "module": "luopan",
    "result": "..."
  },
  "ruleIds": ["RULE-..."],
  "sources": ["SOURCE-..."],
  "confidence": 0.95
}
```

## RAG

Không load toàn bộ knowledge vào prompt.

Pipeline:
1. detect school
2. detect topic
3. retrieve
4. rerank
5. pass evidence
6. generate.

## Source hierarchy

1. Primary/classical source
2. Carefully documented school-specific reference
3. Verified open-source implementation
4. Secondary educational reference
5. Community content
6. AI-generated content = NOT source.

## Conflict

Nếu hai sources khác nhau:
- giữ cả hai
- label school/version
- không merge.
