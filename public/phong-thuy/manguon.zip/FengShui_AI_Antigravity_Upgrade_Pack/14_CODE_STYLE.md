# CODE STYLE

## JavaScript/TypeScript

- pure functions for calculations
- no hidden globals
- no mutation across modules
- explicit names
- small modules
- JSDoc for domain algorithms
- deterministic output.

## Naming

UI:
- Vietnamese.

Code:
- English identifiers.

Examples:
`getMountainFromBearing`
`calculatePolygonCentroid`
`renderLuopan`
`detectRooms`

## No giant files

If file exceeds practical responsibility:
split by domain.

Do not split purely for the sake of splitting.

## No unnecessary dependencies

Before adding dependency:
1. Can Web API solve it?
2. Can existing dependency solve it?
3. Is bundle cost acceptable?
4. Is license compatible?
5. Is security posture acceptable?

If no compelling reason: do not add.

## Drawing

Use:
- SVG for structured vector overlays.
- Canvas 2D for high-frequency drawing.
- DOM for controls/text.

Never use:
- screenshot as La Kinh.
- giant background image as floorplan editor.
