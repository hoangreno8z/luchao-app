# FENG SHUI AI — ANTIGRAVITY UPGRADE PACK

## Mục tiêu

Đây là bộ đặc tả và lệnh triển khai cho Google Antigravity để nâng cấp **trực tiếp** website hiện tại của Nguyễn Huy Hoàng:

- Website: https://lapque.vercel.app/
- Repository: https://github.com/hoangreno8z/luchao-app

Không được tạo một project Phong Thủy mới tách rời.
Không được phá các module Kinh Dịch, Thái Ất, Tử Vi, Bát Tự hiện có.
Chỉ nâng cấp và mở rộng module `phong-thuy`.

## Nguyên tắc sống còn

1. Không code toàn bộ một lần.
2. Mỗi phase phải:
   - inspect
   - plan
   - implement nhỏ
   - lint/typecheck
   - unit test
   - integration test
   - visual test
   - performance test
   - security check
   - build
   - commit/checkpoint
   - mới được sang phase kế tiếp.
3. Nếu một gate thất bại: DỪNG, sửa xong, chạy lại toàn bộ gate của phase đó.
4. Không tự bịa kiến thức phong thủy.
5. Không để LLM tự tính các giá trị xác định được bằng thuật toán.
6. Không trộn hệ phái âm thầm.
7. Không thay đổi logic hiện hữu của Kinh Dịch nếu không được yêu cầu.
8. Không thay framework chỉ để "hiện đại hóa".
9. Không dùng emoji trong UI.
10. Không dùng ảnh raster để vẽ La Kinh, Cửu Cung, tường, phòng, cửa, cầu thang hoặc các lớp phân tích có thể vẽ bằng code.
11. Ưu tiên SVG/Canvas 2D + DOM nhẹ; chỉ dùng WebGL khi thực sự cần.
12. Tối ưu cho điện thoại và máy tính cấu hình thấp.
13. Không gửi API key bí mật xuống browser.
14. Mọi API có dữ liệu người dùng phải có validation, authorization và rate limit.
15. Bản vẽ gốc phải luôn giữ một lớp overlay mờ để so sánh sau nhận diện/vẽ lại.

## Kết quả mong muốn

Biến tab Phong Thủy thành một Computational Feng Shui Workbench:

Bản vẽ → nhận diện hình học → xác định tâm → hướng → La Kinh → 24 Sơn → Cửu Cung → Huyền Không → Hình Pháp/Bát Trạch theo profile → kiểm chứng → AI giải thích.

AI là lớp giải thích và điều phối; calculation engine là nguồn sự thật.
