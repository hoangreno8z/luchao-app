# GHI CHÚ VỀ MÃ NGUỒN MỞ

Bộ ZIP này KHÔNG giả vờ chứa toàn bộ hàng chục nghìn dòng mã nguồn của các repository bên ngoài.

Thay vào đó nó chứa:
- URL chính xác;
- clone scripts;
- license policy;
- cách chọn module;
- yêu cầu attribution;
- master prompt để Antigravity tự tải/đọc khi môi trường có Internet.

Lý do:
- tránh đóng gói các phần không liên quan;
- tránh kéo dependency khổng lồ;
- tránh license contamination;
- tránh làm AI đọc một đống code không cần thiết;
- tránh tăng tải web.

Các repo bên ngoài nên được đặt trong `vendor/` chỉ trong môi trường nghiên cứu/đối chiếu, sau đó chỉ lấy phần cần thiết vào code production.

Nguồn đã xác minh qua GitHub:
- FengShui Master: MIT
- Suangua: MIT
- Chinese Fortune: MIT
- Suan: cần kiểm tra LICENSE tại thời điểm tích hợp.
