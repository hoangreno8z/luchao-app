# MESSAGE TO SEND TO ANTIGRAVITY FIRST

Đọc toàn bộ thư mục này trước khi sửa code.

Sau đó đọc repository:
https://github.com/hoangreno8z/luchao-app

Đọc production:
https://lapque.vercel.app/

Nhiệm vụ không phải viết lại web.

Nhiệm vụ là nâng cấp module Phong Thủy hiện tại thành một Computational Feng Shui Workbench.

Bắt buộc:
- giữ cấu trúc và chức năng hiện tại;
- không sửa các module khác nếu không cần;
- không code một lần;
- làm theo Phase 0 → Phase 20;
- mỗi phase có gate;
- fail = STOP;
- checkpoint trước phase tiếp theo;
- deterministic calculation không đi qua LLM;
- không tự bịa kiến thức;
- không trộn school;
- không emoji;
- không raster diagram;
- mọi La Kinh/Cửu Cung/đường phân khu/bản vẽ vector đều vẽ bằng code;
- bản vẽ gốc luôn có layer mờ để so sánh;
- AI vision chỉ đề xuất, người dùng xác nhận;
- responsive và nhẹ trên thiết bị cấu hình thấp;
- API key chỉ server-side;
- bảo mật theo OWASP API Security Top 10;
- UI phải ngắn gọn, rõ, không chồng chữ, không rối.

Trước tiên CHỈ làm Phase 0.

Không viết Phase 1.

Hãy báo:
1. cấu trúc repo hiện tại;
2. entrypoint Phong Thủy;
3. dependencies;
4. current build command;
5. baseline performance;
6. baseline screenshot plan;
7. risks;
8. kế hoạch Phase 1.

Sau đó DỪNG và chờ lệnh tiếp theo.
