# FLOORPLAN VISION SPEC

## Không được coi AI vision là truth

Vision = candidate geometry.

Mỗi prediction:

```json
{
  "type": "room",
  "label": "phòng ngủ",
  "geometry": {},
  "confidence": 0.91,
  "evidence": [
    "OCR",
    "enclosed_area",
    "door_connectivity"
  ]
}
```

## Pipeline

### A. Input
- image/PDF
- EXIF orientation
- resolution normalization.

### B. Preprocess
- grayscale
- adaptive threshold
- denoise
- line enhancement
- perspective correction nếu có đủ điểm.

### C. Wall detection

Kết hợp:
- Hough/LSD line detection
- line clustering
- parallelism
- thickness consistency
- intersections
- closed topology.

Tường không chỉ là "một đường đen".

### D. Room detection

Một room candidate phải dựa trên:
- enclosed polygon
- wall boundary
- doorway connectivity
- label OCR
- dimensions
- symbol evidence.

### E. Room classification

Các lớp cơ bản:
- living
- bedroom
- kitchen
- toilet
- worship
- office
- dining
- corridor
- balcony
- storage
- stair
- entrance
- garage
- utility
- terrace
- void
- shaft.

Không chắc:
`unknown_room`.

### F. Door detection

Dựa trên:
- gap in wall
- swing arc
- door leaf
- symbol
- connectivity.

### G. Window detection

Dựa trên:
- wall interruption
- parallel thin lines
- architectural symbol.

### H. Stair detection

Dựa trên:
- repeated parallel treads
- directional arrows
- boundary box
- OCR "thang"/"stair" nếu có.

### I. Human review

Hiển thị:
- xanh: high confidence
- vàng: review
- đỏ: conflict.

Không tự khóa.

## Library

Mỗi object có:
- canonical type
- aliases
- vector symbol
- geometry constraints
- recognition cues
- false-positive cues.

Không dùng ảnh icon nếu có thể tạo SVG.

## Ground truth

Tạo fixture:
- simple rectangle house
- L-shape
- T-shape
- courtyard
- multi-block
- irregular polygon
- apartment plan
- office plan
- shop plan.

Mỗi fixture có ground truth JSON.

## Validation

Metrics:
- wall IoU
- room IoU
- door precision/recall
- window precision/recall
- room classification accuracy
- center error in pixels/world units.
