# LUOPAN ENGINE

## Canonical bearing

Use clockwise degrees:
- 0 = true north
- 90 = east
- 180 = south
- 270 = west.

Không tự ý đổi convention giữa modules.

## North basis

```ts
type NorthBasis =
  | "true"
  | "magnetic";
```

Nếu magnetic:
`trueBearing = magneticBearing + declination`.

Declination phải có nguồn/thời điểm.

## 24 Mountains

Không hard-code rải rác.

Một registry duy nhất:

```ts
type Mountain = {
  id: string;
  nameVi: string;
  startDeg: number;
  endDeg: number;
  centerDeg: number;
  trigram?: string;
  element?: string;
  yinYang?: "am" | "duong";
};
```

Boundary handling phải explicit.

## Boundary uncertainty

Nếu bearing nằm gần ranh giới:
```text
UNCERTAIN
```

không ép kết luận.

Ví dụ:
```json
{
  "bearing": 172.4,
  "mountain": null,
  "candidates": ["Dinh", "Ngo"],
  "distanceToBoundary": 0.1,
  "status": "uncertain"
}
```

## Rendering

SVG:
- circle
- ring
- radial lines
- text
- highlight.

Không dùng ảnh La Kinh.

## Coordinate transform

`worldPoint -> polar -> bearing`.

Bản vẽ và La Kinh dùng cùng rotation matrix.

## Tests

Golden bearings:
- exact centers
- exact boundaries
- just-before boundary
- just-after boundary
- 0/360 wrap.
